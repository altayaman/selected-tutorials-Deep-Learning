# Computing with Mixed Distance Functions
