# Training a Siamese Similarity Measure (RNNs)

Placeholder for future purposes
