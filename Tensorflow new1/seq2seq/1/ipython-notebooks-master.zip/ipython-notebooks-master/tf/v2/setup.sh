source /u/nlp/packages/anaconda/bin/activate conda-common
export LD_LIBRARY_PATH=/usr/local/cuda-7.0/lib64:$LD_LIBRARY_PATH
